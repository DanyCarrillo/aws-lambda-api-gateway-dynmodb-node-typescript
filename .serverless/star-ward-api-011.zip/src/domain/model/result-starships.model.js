"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=result-starships.model.js.map