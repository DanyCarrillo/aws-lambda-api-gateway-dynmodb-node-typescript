"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=starships.entity.js.map