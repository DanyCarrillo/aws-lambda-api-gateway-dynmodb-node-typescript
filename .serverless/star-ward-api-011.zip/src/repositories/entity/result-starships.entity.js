"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=result-starships.entity.js.map