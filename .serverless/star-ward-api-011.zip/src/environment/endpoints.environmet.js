"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Endpoints = void 0;
exports.Endpoints = {
    host: "https://swapi.py4e.com/api",
    pahts: {
        starships: "/starships",
    },
};
//# sourceMappingURL=endpoints.environmet.js.map